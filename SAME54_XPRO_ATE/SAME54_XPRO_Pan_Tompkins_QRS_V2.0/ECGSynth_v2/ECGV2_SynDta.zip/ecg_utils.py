"""ECG processing utilities for ECGSynth_v2 pipeline."""

import numpy as np
from scipy.signal import butter, filtfilt, resample
import neurokit2 as nk


def bandpass_filter(signal, fs, lowcut=0.5, highcut=45.0, order=3):
    """Apply Butterworth bandpass filter."""
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return filtfilt(b, a, signal)


def detect_rpeaks(ecg_signal, fs):
    """Detect R-peaks using NeuroKit2."""
    cleaned = nk.ecg_clean(ecg_signal, sampling_rate=fs, method="neurokit")
    _, rpeaks_info = nk.ecg_peaks(cleaned, sampling_rate=fs, correct_artifacts=True)
    return rpeaks_info["ECG_R_Peaks"]


def segment_beats(ecg_signal, rpeaks, fs):
    """Segment ECG into individual beat templates centered on R-peaks.

    Returns list of beat arrays, each from mid-RR to mid-RR around the R-peak.
    """
    beats = []
    for i in range(1, len(rpeaks) - 1):
        # Start at midpoint between previous and current R-peak
        start = (rpeaks[i - 1] + rpeaks[i]) // 2
        # End at midpoint between current and next R-peak
        end = (rpeaks[i] + rpeaks[i + 1]) // 2
        if start >= 0 and end <= len(ecg_signal):
            beat = ecg_signal[start:end].copy()
            if len(beat) > 50:  # minimum viable beat length
                beats.append(beat)
    return beats


def align_beat(template, target_length):
    """Stretch/compress a beat template to match target length using interpolation."""
    if len(template) == target_length:
        return template
    x_old = np.linspace(0, 1, len(template))
    x_new = np.linspace(0, 1, target_length)
    return np.interp(x_new, x_old, template)


def compute_hr_from_rpeaks(rpeaks, fs):
    """Compute heart rate (bpm) from R-peak indices."""
    if len(rpeaks) < 2:
        return np.nan
    rr_intervals_ms = np.diff(rpeaks) / fs * 1000.0
    return 60000.0 / np.mean(rr_intervals_ms)


def compute_rr_intervals(rpeaks, fs):
    """Compute RR intervals in milliseconds."""
    if len(rpeaks) < 2:
        return np.array([])
    return np.diff(rpeaks) / fs * 1000.0


def compute_hrv_metrics(rr_intervals_ms):
    """Compute HRV metrics from RR intervals (in ms)."""
    if len(rr_intervals_ms) < 2:
        return {'sdnn': np.nan, 'rmssd': np.nan, 'pnn50': np.nan, 'cv': np.nan}

    sdnn = np.std(rr_intervals_ms, ddof=1)
    rr_diff = np.diff(rr_intervals_ms)
    rmssd = np.sqrt(np.mean(rr_diff ** 2))
    nn50 = np.sum(np.abs(rr_diff) > 50)
    pnn50 = nn50 / len(rr_diff) if len(rr_diff) > 0 else 0.0
    cv = sdnn / np.mean(rr_intervals_ms) if np.mean(rr_intervals_ms) > 0 else 0.0

    return {'sdnn': sdnn, 'rmssd': rmssd, 'pnn50': pnn50, 'cv': cv}


def remove_p_wave(beat, fraction=0.15):
    """Remove P-wave from a beat by zeroing the initial segment.

    P-wave typically occupies the first 10-15% of the beat before QRS.
    Replace with small random fluctuation to simulate absent P-wave.
    """
    p_end = int(fraction * len(beat))
    baseline = np.mean(beat[p_end:p_end + 10]) if p_end + 10 < len(beat) else 0
    beat_modified = beat.copy()
    beat_modified[:p_end] = baseline + np.random.normal(0, 0.5, p_end)
    return beat_modified


def add_f_waves(signal, fs, amplitude, freq_range=(4, 8)):
    """Add fibrillatory waves (irregular small rapid oscillations)."""
    t = np.arange(len(signal)) / fs
    f_wave = np.zeros(len(signal))
    # Sum multiple frequency components for realistic f-waves
    for _ in range(3):
        freq = np.random.uniform(freq_range[0], freq_range[1])
        phase = np.random.uniform(0, 2 * np.pi)
        f_wave += amplitude * np.sin(2 * np.pi * freq * t + phase)
    # Add some randomness
    f_wave += amplitude * 0.3 * np.random.randn(len(signal))
    return signal + f_wave


def normalize_signal(signal):
    """Normalize signal to zero mean and unit variance."""
    std = np.std(signal)
    if std == 0:
        return signal - np.mean(signal)
    return (signal - np.mean(signal)) / std


def scale_to_adc_range(signal, target_range=(-400, 400)):
    """Scale signal to match target ADC integer range."""
    sig_min, sig_max = signal.min(), signal.max()
    if sig_max == sig_min:
        return np.zeros_like(signal)
    # Scale to target range
    scaled = (signal - sig_min) / (sig_max - sig_min)
    scaled = scaled * (target_range[1] - target_range[0]) + target_range[0]
    return scaled.astype(np.int16)
